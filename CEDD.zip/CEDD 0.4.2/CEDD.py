import datetime
import time
import os
import webbrowser
import sys
import pyautogui
import system.directive_functions as directive_functions

def clean():
    os.system("cls")

def store():
    print('该功能暂未完成....')

def open():
    print('该功能暂未完成....')

def today():
    print(datetime.datetime.today())

#初始化
searcha = ""
searchb = ""
searchc = ""
if os.path.isdir('app/') == False:
    os.makedirs('app/')
if os.path.isdir('bin/') == False:
    os.makedirs('bin/')
if os.path.isdir('download/') == False:
    os.makedirs('download/')
if os.path.isdir('system/') == False:
    os.makedirs('system/')
if os.path.isdir('system/directive_functions') == False:
    os.makedirs('system/directive_functions')
if os.path.isfile('system/user.config') == False:
    with open('system/user.config','w') as f:
        f.close()
pyautogui.hotkey('f11')

directive_functions.login()

#主程序
while True:
    t = input("CEDD->")
    if t.lower() == "help":
        directive_functions.help()
    elif t.lower() == "setting":
        os.startfile(r"app\\setting.py")
    elif t.lower() == "clean":
        clean()
    elif t.lower() == "store":
        store()
    elif t[0:5].lower() == "sleep":
        directive_functions.sleep(t)
    elif t[0:6].lower() == "search":
        directive_functions.search(t,searcha,searchb,searchc)
    elif t[0:5].lower() == "inter":
        directive_functions.inter(t)
    elif t.lower() == "cmd":
        os.startfile(r"app\\cmd.py")
    elif t.lower() == "down":
        os.startfile(r"app\\down.py")
    elif t.lower() == "open":
        open()
    elif t.lower() == "notepad":
        os.startfile(r"app\\notepad.py")
    elif t.lower() == "calc":
        os.system("calc")
    elif t.lower() == "egg game":
        os.startfile(r"app\\egg game.pyw")
    elif t.lower() == "today":
        today()
    elif t.lower() == "ls":
        directive_functions.ls()
    elif t.lower() == "exit" or t.lower() == 'exit()':
        print('系统已关闭')
        break
    elif t.lower() == 'shutdown':
        t == input("是否关机系统（Y/N）")
        if t.lower == "y":
            if sys.platform == 'win32':
                os.system('shutdown -s')
            elif sys.platform == 'linux':
                os.system('shutdown –h now')
            elif sys.platform == 'darwin':
                os.system('sudo shutdown -h now')
            else:
                os.system('shutdown -p')
    else:
        if not(t == ''):
            print('\033[31m'+'没有'+'\''+t+'\''+'命令'+'\033[0m')
