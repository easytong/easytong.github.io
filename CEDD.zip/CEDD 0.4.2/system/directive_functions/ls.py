import os

def ls():
    file = "app\\"
    list_directory = os.listdir(file)
    filelists = []
    for directory in list_directory:
        if(os.path.isfile(directory)):
            filelists.append(directory)