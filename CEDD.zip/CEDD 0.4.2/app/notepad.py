print("\033[34m======================\033[0m")
print("\033[32m1.写入文件 exit().退出\033[0m")
print("\033[34m======================\033[0m")
while True:
    t = input("CEDD>notepad->")
    if t == "1":
        print(f'请输入文件名\n')
        a = input("CEDD>notepad>1->")
        print(f'请输入文件内容\n')
        b = input("CEDD>notepad>1->")
        with open(a,'w') as f:
            f.write(b)
            f.close() 
    elif t == "exit()":
        break 
