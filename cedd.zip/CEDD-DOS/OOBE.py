import time
import os

print("欢迎使用CEDD！")
os.system("pause")
os.system("cls")

#加载文件
for i in range(2):
    for i in range(1,4):
        n = "."
        print("正在加载文件" + n * i)
        time.sleep(1)
        os.system("cls")

#安装模块
os.system("pip install wget")
os.system("pip install pygame")
os.system("cls")

#设置用户名和密码
t = input("请设置用户名称")
inf = []
inf.append(t)
print("设置成功 您的用户名是" + t)
t = input("请设置用户密码")
inf.append(t)
print("设置成功 您的密码是" + t)

#完成设置
f = open('attribute.csv','w')
f.write(','.join(inf) + '\n')
f.close()
print("已完成设置")


