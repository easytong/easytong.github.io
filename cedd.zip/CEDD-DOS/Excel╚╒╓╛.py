import streamlit as st
import pandas as pd
uploaded_file = st.file_uploader( "excel 文件")
if uploaded_file is None:
    st.stop()
dfs = pd.read_excel(uploaded_file,None)