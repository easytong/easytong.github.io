import datetime
import time
import os
import webbrowser

#登录界面
def login():
    print(". . . . . . . . . . . . . . . . . . . .")
    print("  . . . . . . . . . . . . . . . . . .")
    print("    . . . . . . . . . . . . . . . .")
    print("      . . . . . . . . . . . . . .")
    print("        . . . . . . . . . . . .")
    print("  c        . . . . . . . . . .")
    print("  e          . . . . . . . .")
    print("  d            . . . . . .")
    print("  d     0        . . . .")
    print("        .          . .")
    print("        0        . . . .")
    print("--------------CEDD-DOS V0.0-------------")

#应用函数
def help():
    print("\033[34m=======================\033[0m")
    print("\033[32mHELP     查看帮助\033[0m")
    print("\033[32mSETTING  打开设置面板\033[0m")
    print("\033[32mCLEAN    清屏\033[0m")
    print("\033[32mSTORE    打开应用商店\033[0m")
    print("\033[32mSEARCH   互联网搜索\033[0m")
    print("\033[32mSLEEP    暂停指定秒数\033[0m")
    print("\033[32mINTER    打开指定网址\033[0m")
    print("\033[32mCMD      打开系统指令\033[0m")
    print("\033[32mDOWN     下载指定文件\033[0m")
    print("\033[32mOPEN     打开指定程序\033[0m")
    print("\033[32mNOTEPAD  打开记事本\033[0m")
    print("\033[32mCALC     打开计算器\033[0m")
    print("\033[32mEGG GAME 打开捕蛋器\033[0m")
    print("\033[32mTODAY    显示当前时间\033[0m")
    print("\033[32mLS       显示所有应用程序\033[0m")
    print("\033[32mEXIT()   退出\033[0m")
    print("\033[34m========================\033[0m")

def setting():
    print("\033[34m========================\033[0m")
    print("\033[32mSYSVER   关于CEDD\033[0m")
    print("\033[32mSEARCH   更改搜索引擎\033[0m")
    print("\033[32mUSER     修改用户名\033[0m")
    print("\033[32mPASS     修改密码\033[0m")
    print("\033[32mCOLOR    更改系统字体颜色\033[0m")
    print("\033[32mEXIT()   退出\033[0m")
    print("\033[34m========================\033[0m")
    while True:    
        t = input("CEDD>setting->")
        if t == "sysver":
            print("CEDD-DOS V0.1.07")
        elif t == "search":
            print("\033[34m==========================\033[0m")
            print("\033[32m1.必应 2.百度 3.360 4.搜狗\033[0m")
            print("\033[34m==========================\033[0m")
            t = input("CEDD>setting>search->")
            if t == "1":
                searcha = "cn.bing.com/"
                searchb = "search?q="
                searchc = "&qs=n&form=QBRE&sp=-1&lq=0&pq=baidu&sc=10-5&sk=&cvid=CD547A7AA8EC4E89BBD6D3443F0E3E2F&ghsh=0&ghacc=0&ghpl=&adlt=strict"
                print("您选择了:必应")
            elif t == "2":
                searcha = "www.baidu.com/"
                searchb = "s?wd="
                searchc = "&rsv_spt=1&rsv_iqid=0xfaf73b480001d1da&issp=1&f=8&rsv_bp=1&rsv_idx=2&ie=utf-8&rqlang=cn&tn=baiduhome_pg&rsv_enter=1&rsv_dl=tb&oq=1&rsv_btype=t&inputT=5021&rsv_t=e82eEfBIrQnYq%2FhZfAZueH29WQ%2F2po5dRdo9GMHS7X4iKEqpKbpoUPrnKnBhZGpJoETJ&rsv_pq=a52c6c680001c0bd&rsv_sug3=12&rsv_sug1=12&rsv_sug7=100&rsv_sug2=0&rsv_sug4=5021"
                print("您选择了:百度")
            elif t == "3":
                searcha = "www.so.com/"
                searchb = "s?q="
                searchc = "&src=srp&ssid=&fr=hao_360so_b_cube&sp=af7&cp=09c000aaf7&psid=c0307ceb4b8daaaa5f5446b7642ef762"
                print("您选择了:360")
            elif t == "4":
                searcha = "www.sogou.com/"
                searchb = "web?query="
                searchc = "&_asf=www.sogou.com&_ast=&w=01019900&p=40040100&ie=utf8&from=index-nologin&s_from=index&sut=2122&sst0=1691641946616&lkt=6%2C1691641944495%2C1691641946351&sugsuv=1691641940021375&sugtime=1691641946616"
                print("您选择了:搜狗")
        elif t == "user":
            pass
        elif t == "pass":
            pass
        elif t == "color":
            print("\033[34m==========================\033[0m")
            print("\033[32m1.默认 2.绿色 3.蓝色 4.红色\033[0m")
            print("\033[34m==========================\033[0m")
            t = input("CEDD>setting>color->")
            if t == "1":
                os.system("color 0")
            elif t == "2":
                os.system("color 2")
            elif t == "3":
                os.system("color 1")
            elif t == "4":
                os.system("color 4")
        elif t == "exit()":
            break


def clean():
    os.system("cls")

def store():
    pass

def search():
    print("\033[34m==========================\033[0m")
    print("\033[32m1.搜索指定内容 exit().退出\033[0m")
    print("\033[34m==========================\033[0m")
    while True:    
        t = input("CEDD>search->")
        if t == "1":
            print("您选择了输入网址名称")
            t = input("CEDD>search->")
            webbrowser.open("https://"+ searcha + searchb + t + searchc)
        elif t == "exit()":
            break
        else:
            print("此选项无效")

def inter():
    print("\033[34m==========================\033[0m")
    print("\033[32m1.输入网址名称 exit().退出\033[0m")
    print("\033[34m==========================\033[0m")
    while True:    
        t = input("CEDD>inter->")
        if t == "1":
            print("您选择了输入网址名称")
            t = input("CEDD>inter->")
            webbrowser.open(t)
        elif t == "exit()":
            break
        else:
            print("此选项无效")

def cmd():
    print("\033[34m====================\033[0m")
    print("\033[32m输入指令 exit().退出\033[0m")
    print("\033[34m====================\033[0m")
    while True:
        t = input("CEDD>cmd->")
        if t == "exit()":
            break
        else:
            os.system(t)

def down():
    pass

def open():
    pass

def notepad():
    print("\033[34m======================\033[0m")
    print("\033[32m1.写入文件 exit().退出\033[0m")
    print("\033[34m======================\033[0m")
    while True:
        t = input("CEDD>notepad->")
        if t == "1":
            print(f'模式:正常写入\n')
            t = input("CEDD>notepad>1->")
            with open(t,'w') as f:
                f.write(t)
                f.close() 
        elif t == "exit()":
            break 

def calc():
    print("\033[34m================================================================================\033[0m")
    print("\033[32m1.输入表达式 2.进制转换 3.长度单位转换 4.面积单位转换 5.重量单位转换 exit().退出\033[0m")
    print("\033[34m================================================================================\033[0m")
    while True:
        t = input("CEDD>calc->")
        if t == "exit()":
            break
        elif t == "1":
            print("请输入表达式")
            t = input("CEDD>calc>1->")
            try:
                print(eval(t))
            except NameError:
                print("请输入表达式")
            except ZeroDivisionError:
                print("除数不能为0")
        elif t == "2":
            print("\033[34m==================================================================================================\033[0m")
            print("\033[32m1.2进制转10进制 2.10进制转2进制 3.8进制转10进制 4.10进制转8进制 5.16进制转10进制 6.10进制转16进制\033[0m")
            print("\033[34m==================================================================================================\033[0m")
            t = input("CEDD>calc>2->")
            if t == "1":
                print("您选择了:2进制转10进制")
                t = input("CEDD>calc>2>1->")
                print(int(t,2))
            elif t == "2":
                print("您选择了:10进制转2进制")
                t = input("CEDD>calc>2>2->")
                print(bin(int(t)))
            elif t == "3":
                print("您选择了:8进制转10进制")
                t = input("CEDD>calc>2>3->")
                print(int(t,8))
            elif t == "4":
                print("您选择了:10进制转8进制")
                t = input("CEDD>calc>2>4->")
                print(oct(int(t)))
            elif t == "5":
                print("您选择了:16进制转10进制")
                t = input("CEDD>calc>2>5->")
                print(int(t,16))
            elif t == "6":
                print("您选择了:10进制转16进制")
                t = input("CEDD>calc>2>6->")
                print(hex(int(t)))  
        elif t == "3":
            print("\033[34m====================================================\033[0m")
            print("\033[32m1.毫米转米 2.厘米转米 3.分米转米 4.米转千米 5.米转毫米\033[0m")
            print("\033[34m====================================================\033[0m")
            t = input("CEDD>calc>3->")
            if t == "1":
                print("您选择了:毫米转米")
                t = input("CEDD>calc>3>1->")
                print(t/1000 + "米")
            elif t == "2":
                print("您选择了:厘米转米")
                t = input("CEDD>calc>3>2->")
                print(t/100 + "米")
            elif t == "3":
                print("您选择了:分米转米")
                t = input("CEDD>calc>3>3->")
                print(t/10 + "米")
            elif t == "4":
                print("您选择了:米转千米")
                t = input("CEDD>calc>3>4->")
                print(t/1000 + "千米")
            elif t == "5":
                print("您选择了:米转毫米")
                t = input("CEDD>calc>3>5->")
                print(t*1000 + "毫米")
        elif t == "4":
            print("\033[34m==========================================\033[0m")
            print("\033[32m1.毫克转克 2.克转千克 3.千克转吨 4.吨转毫克\033[0m")
            print("\033[34m==========================================\033[0m")
            t = input("CEDD>calc>3->")
            if t == "1":
                print("您选择了:毫克转克")
                t = float(input("CEDD>calc>3>1->"))
                a = str(eval(int(t)/1000))
                print(a + "克")
            elif t == "2":
                print("您选择了:克转千克")
                t = float(input("CEDD>calc>3>2->"))
                print(t/1000 + "千克")
            elif t == "3":
                print("您选择了:千克转吨")
                t = float(input("CEDD>calc>3>3->"))              
                print(t/1000 + "吨")
            elif t == "4":
                print("您选择了:吨转毫克")
                t = float(input("CEDD>calc>3>4->"))
                print(t*100000000 + "毫克")

def today():
    print(datetime.datetime.today())

def ls():
    pass


#初始化
searcha = ""
searchb = ""
searchc = ""
login()

#主程序
while True:
    t = input("CEDD->")
    if t == "help":
        help()
    elif t == "setting":
        setting()
    elif t == "clean":
        clean()
    elif t == "store":
        store()
    elif t[0:5] == "sleep":
        i = t[6:]
        print(i)
        n = 0
        while(n == i):
            time.sleep(1)
            n += 1
    elif t == "search":
        search()
    elif t == "inter":
        inter()
    elif t == "cmd":
        cmd()
    elif t == "down":
        down()
    elif t == "open":
        open()
    elif t == "notepad":
        notepad()
    elif t == "calc":
        calc()
    elif t == "egg game":
        os.startfile(r"C:\Users\lukeo\OneDrive\CEDD-DOS\sof\捕蛋器.pyw")
    elif t == "today":
        today()
    elif t == "ls":
        ls()
    elif t == "exit()":
        break