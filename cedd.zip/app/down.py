import wget

print("\033[34m=======================\033[0m")
print("\033[32m请输入下载源 exit().退出\033[0m")
print("\033[34m=======================\033[0m")
while True:
    url = input("CEDD>down->")
    if url == "exit()":
        break
    wget.download(f'url',"download/")
