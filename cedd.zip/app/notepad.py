print("\033[34m======================\033[0m")
print("\033[32m1.写入文件 exit().退出\033[0m")
print("\033[34m======================\033[0m")
while True:
    t = input("CEDD>notepad->")
    if t == "1":
        print(f'模式:正常写入\n')
        t = input("CEDD>notepad>1->")
        with open(t,'w') as f:
            f.write(t)
            f.close() 
    elif t == "exit()":
        break 
