print("\033[34m================================================================================\033[0m")
print("\033[32m1.输入表达式 2.进制转换 3.长度单位转换 4.面积单位转换 5.重量单位转换 exit().退出\033[0m")
print("\033[34m================================================================================\033[0m")
while True:
    t = input("CEDD>calc->")
    if t == "exit()":
        break
    elif t == "1":
        print("请输入表达式")
        t = input("CEDD>calc>1->")
        try:
            print(eval(t))
        except NameError:
            print("请输入表达式")
        except ZeroDivisionError:
            print("除数不能为0")
    elif t == "2":
        print("\033[34m==================================================================================================\033[0m")
        print("\033[32m1.2进制转10进制 2.10进制转2进制 3.8进制转10进制 4.10进制转8进制 5.16进制转10进制 6.10进制转16进制\033[0m")
        print("\033[34m==================================================================================================\033[0m")
        t = input("CEDD>calc>2->")
        t = int(t)
        if t == "1":
            print("您选择了:2进制转10进制")
            t = input("CEDD>calc>2>1->")
            print(int(t,2))
        elif t == "2":
            print("您选择了:10进制转2进制")
            t = input("CEDD>calc>2>2->")
            print(bin(int(t)))
        elif t == "3":
            print("您选择了:8进制转10进制")
            t = input("CEDD>calc>2>3->")
            print(int(t,8))
        elif t == "4":
            print("您选择了:10进制转8进制")
            t = input("CEDD>calc>2>4->")
            print(oct(int(t)))
        elif t == "5":
            print("您选择了:16进制转10进制")
            t = input("CEDD>calc>2>5->")
            print(int(t,16))
        elif t == "6":
            print("您选择了:10进制转16进制")
            t = input("CEDD>calc>2>6->")
            print(hex(int(t)))  
    elif t == "3":
        print("\033[34m====================================================\033[0m")
        print("\033[32m1.毫米转米 2.厘米转米 3.分米转米 4.米转千米 5.米转毫米\033[0m")
        print("\033[34m====================================================\033[0m")
        t = input("CEDD>calc>3->")
        if t == "1":
            print("您选择了:毫米转米")
            t = input("CEDD>calc>3>1->")
            print(t/1000 + "米")
        elif t == "2":
            print("您选择了:厘米转米")
            t = input("CEDD>calc>3>2->")
            print(t/100 + "米")
        elif t == "3":
            print("您选择了:分米转米")
            t = input("CEDD>calc>3>3->")
            print(t/10 + "米")
        elif t == "4":
            print("您选择了:米转千米")
            t = input("CEDD>calc>3>4->")
            print(t/1000 + "千米")
        elif t == "5":
            print("您选择了:米转毫米")
            t = input("CEDD>calc>3>5->")
            print(t*1000 + "毫米")
    elif t == "4":
        print("\033[34m==========================================\033[0m")
        print("\033[32m1.毫克转克 2.克转千克 3.千克转吨 4.吨转毫克\033[0m")
        print("\033[34m==========================================\033[0m")
        t = input("CEDD>calc>3->")
        if t == "1":
            print("您选择了:毫克转克")
            t = input("CEDD>calc>3>1->")
            a = int
            a = str(eval(int(t)/1000))
            print(a + "克")
        elif t == "2":
            print("您选择了:克转千克")
            t = float(input("CEDD>calc>3>2->"))
            print(t/1000 + "千克")
        elif t == "3":
            print("您选择了:千克转吨")
            t = float(input("CEDD>calc>3>3->"))              
            print(t/1000 + "吨")
        elif t == "4":
            print("您选择了:吨转毫克")
            t = float(input("CEDD>calc>3>4->"))
            print(t*100000000 + "毫克")