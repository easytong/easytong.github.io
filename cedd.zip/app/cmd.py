import os

print("\033[34m====================\033[0m")
print("\033[32m输入指令 exit().退出\033[0m")
print("\033[34m====================\033[0m")
while True:
    t = input("CEDD>cmd->")
    if t == "exit()":
        break
    else:
        os.system(t)