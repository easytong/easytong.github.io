def Progress_bar(scale):
    """
    这是进度条函数
    """
    import time
    print("开始加载文件".center(scale//2,"-"))
    start=time.perf_counter()
    for i in range(scale+1):
        a="*"*i
        b="."*(scale-i)
        c=(i/scale)*100
        dur=time.perf_counter()-start
        print("\r{:^3.0f}%[{}{}]{:.2f}s".format(c,a,b,dur),end="")
        time.sleep(0.1)
    print("\n"+"结束加载文件".center(scale//2,'-'))