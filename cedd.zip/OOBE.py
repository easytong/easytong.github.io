try:
    import time
    import os
    import Public_Functions

    print("欢迎使用CEDD！")
    os.system("pause")
    os.system("cls")

    #检测是否已有必要第三方库
    print('开始检测是否已有必要第三方库')
    try:
        import wget
        import pygame
        import pyautogui
        import art
        print('')
        print("已有必要第三方库")
        time.sleep(1)
        os.system("cls")
    except:
        print("无法检测到必要第三方库")
        print("开始下载必要第三方库")
        #安装模块
        os.system("sys\\Download_libraries.bat")
        os.system("cls")

    #加载文件
    Public_Functions.Progress_bar(50)
    print('')

    time.sleep(0.1)

    #设置用户名和密码
    username = input("请设置用户名称:")
    print("设置成功 您的用户名是" + username)
    print('')
    password = input("请设置用户密码:")
    print("设置成功 您的密码是" + password)
    print('')

    #完成设置
    account = open('system/user.config',mode='w+')
    account.write(f'{username}\n')
    account.write(f'{password}\n')
    account.close()
    
    t = input("已完成设置 是否打开CEDD(Y/N)")
    if t == 'Y':
        os.system("start.bat")
        quit()
    else:
        quit()
except Exception as e:
    print("\033[31mError:{e}\033[0m")
