pip install art -i https://pypi.tuna.tsinghua.edu.cn/simple
pip install rich -i https://pypi.tuna.tsinghua.edu.cn/simple
pip install wget -i https://pypi.tuna.tsinghua.edu.cn/simple
pip install pygame -i https://pypi.tuna.tsinghua.edu.cn/simple
pip install pyautogui