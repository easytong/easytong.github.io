import time

def sleep(t):
    i = t[6:]
    try:
        for j in range(int(i)):
            print(f'\r已等待{j}秒',end='')
            time.sleep(1)
        print(f'\r已等待{int(i)}秒',end='')
        print('')
        print('等待完毕')
    except:
        if i == '':
            pass
        else:
            print('\033[31m参数错误\033[0m')