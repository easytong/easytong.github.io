import os

#设置函数
def setting():
    print("\033[34m========================\033[0m")
    print("\033[32mSYSVER   关于CEDD\033[0m")
    print("\033[32mSEARCH   更改搜索引擎\033[0m")
    print("\033[32mUSER     修改用户名及密码\033[0m")
    print("\033[32mCOLOR    更改系统字体颜色\033[0m")
    print("\033[32mEXIT()   退出\033[0m")
    print("\033[34m========================\033[0m")
    while True:    
        t = input("CEDD>setting->")
        if t == "sysver":
            print("CEDD-DOS V0.1.07")
        elif t == "search":
            print("\033[34m==========================\033[0m")
            print("\033[32m1.必应 2.百度 3.360 4.搜狗\033[0m")
            print("\033[34m==========================\033[0m")
            t = input("CEDD>setting>search->")
            if t == "1":
                searcha = "cn.bing.com/"
                searchb = "search?q="
                searchc = "&qs=n&form=QBRE&sp=-1&lq=0&pq=baidu&sc=10-5&sk=&cvid=CD547A7AA8EC4E89BBD6D3443F0E3E2F&ghsh=0&ghacc=0&ghpl=&adlt=strict"
                print("您选择了:必应")
            elif t == "2":
                searcha = "www.baidu.com/"
                searchb = "s?wd="
                searchc = "&rsv_spt=1&rsv_iqid=0xfaf73b480001d1da&issp=1&f=8&rsv_bp=1&rsv_idx=2&ie=utf-8&rqlang=cn&tn=baiduhome_pg&rsv_enter=1&rsv_dl=tb&oq=1&rsv_btype=t&inputT=5021&rsv_t=e82eEfBIrQnYq%2FhZfAZueH29WQ%2F2po5dRdo9GMHS7X4iKEqpKbpoUPrnKnBhZGpJoETJ&rsv_pq=a52c6c680001c0bd&rsv_sug3=12&rsv_sug1=12&rsv_sug7=100&rsv_sug2=0&rsv_sug4=5021"
                print("您选择了:百度")
            elif t == "3":
                searcha = "www.so.com/"
                searchb = "s?q="
                searchc = "&src=srp&ssid=&fr=hao_360so_b_cube&sp=af7&cp=09c000aaf7&psid=c0307ceb4b8daaaa5f5446b7642ef762"
                print("您选择了:360")
            elif t == "4":
                searcha = "www.sogou.com/"
                searchb = "web?query="
                searchc = "&_asf=www.sogou.com&_ast=&w=01019900&p=40040100&ie=utf8&from=index-nologin&s_from=index&sut=2122&sst0=1691641946616&lkt=6%2C1691641944495%2C1691641946351&sugsuv=1691641940021375&sugtime=1691641946616"
                print("您选择了:搜狗")
        elif t == "user":
            print("\033[34m==============\033[0m")
            print("\033[32m请设置用户名称\033[0m")
            print("\033[34m==============\033[0m")
            username = input("CEDD>setting>user->")
            print("设置成功 您的用户名是" + username) 
            print("\033[34m==============\033[0m")
            print("\033[32m请设置用户密码\033[0m")
            print("\033[34m==============\033[0m")
            password = input("CEDD>setting>user->")
            print("设置成功 您的用户名是" + password) 
            account = open('system/user.config',mode='w+')
            account.write(f'{username}\n')
            account.write(f'{password}\n')
            account.close()
            print("已完成设置")
        elif t == "color":
            print("\033[34m==========================\033[0m")
            print("\033[32m1.默认 2.绿色 3.蓝色 4.红色\033[0m")
            print("\033[34m==========================\033[0m")
            t = input("CEDD>setting>color->")
            if t == "1":
                os.system("color 0")
            elif t == "2":
                os.system("color 2")
            elif t == "3":
                os.system("color 1")
            elif t == "4":
                os.system("color 4")
        elif t == "exit()":
            break