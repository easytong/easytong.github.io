import webbrowser

def search(t, searcha, searchb, searchc):
    i = t[7:]
    webbrowser.open("https://"+ searcha + searchb + i + searchc)