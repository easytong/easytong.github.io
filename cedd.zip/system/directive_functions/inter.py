import webbrowser

def inter(t):
    i = t[6:]
    webbrowser.open(i)