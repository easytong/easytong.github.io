from system.directive_functions.help import help
from system.directive_functions.setting import setting
from system.directive_functions.login import login
from system.directive_functions.sleep import sleep
from system.directive_functions.inter import inter
from system.directive_functions.search import search