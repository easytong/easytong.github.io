#登录界面
def login():
    import time
    import base64
    account_open = open('system/user.config',mode='r')
    account_info = account_open.readlines()
    un_username = account_info[0]
    global username
    username = un_username[0:-1]
    un_password = account_info[1]
    global password
    password = un_password[0:-1]
    account_open.close()    
    try:
        import art
    except:
        print("\033[031mError:导入art库失败,请确定电脑已经安装了art库\033[0m")
        time.sleep(10)
        quit()
    try:
        username = str(username)
        password = str(password)
    except:
        print("\033[031mError:账户文件读取失败,请尝试打开OOBE修复\033[0m")
        time.sleep(10)
        quit()
    try:
        sysver = open('system\\ver.sys',mode='r')
        sysver.seek(0, 0)
        ver_open = sysver
        Ver = ver_open.read()
    except:
        print("\033[031mError:版本信息读取失败,请尝试打开OOBE修复\033[0m")
        time.sleep(10)
        quit()
    art.tprint("CEDD-DOS")
    print("----------------------CEDD-DOS V0.4.0---------------------")
    print('\033[032m'+'Welcome!'+'\033[0m')
    while True:
        userspassword = input('密码:')
        if userspassword == password:
            print('\033[32m密码正确\033[0m')
            break
        else:
            print('\033[31m密码错误！\033[0m')

